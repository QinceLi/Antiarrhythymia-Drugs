/* This file defines the functions that can be performed with the Variable object defined in
   Variables.h*/

#include "Header.h"

using namespace std;

Variables::Variables(double V_init,double Cai_init,double CaSR_init,double CaSS_init,double Nai_init,double Ki_init)
{
  Volt=V_init;
  Volt2=V_init;
  Cai=Cai_init;
  CaSR=CaSR_init;
  CaSS=CaSS_init;
  Nai=Nai_init;
  Ki=Ki_init;
  M= 0.037396266233898176000;   //0.;
  H= 0.193531112266500660000;   //0.75;
  J= 0.170193474094604810000;   //0.75;
  Xr1= 0.013720983480392804000; //0.;
  Xr2= 0.318614799111897550000; //1.;
  Xs= 0.009711833626984207200;  //0.;
  R= 0.000000318575104674730;   //0.;
  S= 0.999952334011770310000;   //1.;
  D= 0.000177883400051902350;   //0.;
  F= 0.988991405078883500000;   //1.;
  F2=0.995358028564252040000;   //1.;
  FCass= 0.999978028985132990000;   //1.;
  RR= 0.992241352890124500000;  //1.;
  OO= 0.000000129042183903380;  //0.;

  printf("Variables initialized\n");
}



void Variables::writebackup(double *t)
{
  static char filename[300];

  sprintf(filename,"%s","PointBackupData.dat");

  ofstream oo(filename,ios::app);
  if(!oo)
    {
      printf("cannot open file %s\n",filename);
      exit(1);
    }

  oo << *t << "\t";  //Ӧ����Ht???
  oo << Volt<< "\t";
  oo << Volt2 << "\t";
  oo << Cai << "\t";
  oo << CaSR << "\t";
  oo << CaSS << "\t";
  oo << Nai << "\t";
  oo << Ki << "\t";
  oo << M << "\t";
  oo << H << "\t";
  oo << J << "\t";
  oo << Xr1 << "\t";
  oo << Xr2 << "\t";
  oo << Xs << "\t";
  oo << S << "\t";
  oo << R << "\t";
  oo << D << "\t";
  oo << F << "\t";
  oo << F2 << "\t";
  oo << FCass << "\t";
  oo << RR << "\t";
  oo << OO << "\t";
  oo << Itot;    //Itot�ĳ�ֵ��ô���ģ�����
  oo << endl;
  oo.close();

}





