/* This function performs the actual computations of currents, concentration changes
   voltage changes, gate state changes involved in a single time step. Every 100 timesteps
   the values of all currents are written to file. */

#include "Header.h"

extern double knak;
extern double KmNa;
extern double KmK;
extern double knaca;
extern double KmNai;
extern double KmCa;
extern double ksat;
extern double n;


extern double Ko;
extern double Cao;
extern double Nao;


extern double Bufc;
extern double Kbufc;
extern double Bufsr;
extern double Kbufsr;
extern double Bufss;
extern double Kbufss;

extern double Vmaxup;
extern double Kup;
extern double Vrel;
extern double k1_;
extern double k2_;
extern double k3;
extern double k4;
extern double EC;
extern double maxsr;
extern double minsr;
extern double Vleak;
extern double Vxfer;


extern double pKNa;


extern double CAPACITANCE;
extern double RTONF;
extern double F;
extern double R;
extern double T;


extern double Gkr;
extern double Gks;
extern double GK1;
extern double Gto;
extern double GNa;
extern double GbNa;
extern double GCaL;
extern double GbCa;
extern double GpCa;
extern double KpCa;
extern double GpK;


extern double Vc;
extern double Vsr;
extern double Vss;

extern double period;

//����APD�Ĳ���  liang_change
extern double Vmax;  //liang
extern double t_0;  //liang
extern double t_end;  //liang
extern double Vrest;  //liang
extern double ADP;  //liang
extern double V_pre;  //liang
extern double V_post;  //liang
extern double Slope_pre;  //liang
extern double Slope_post;  //liang


void Step(Variables *V,double HT,double *tt,int step,double Istim)
{

#define v(array_pointer,i,j) (*(V->array_pointer+i*V->NJ +j))  //??? liang_question



  double IKr;
  double IKs;
  double IK1;
  double Ito;
  double INa;
  double IbNa;
  double ICaL;
  double INaL;  //liang_change
  double IbCa;
  double INaCa;
  double IpCa;
  double IpK;
  double INaK;
  double Irel;
  double Ileak;
  double Iup;
  double Ixfer;
  double k1;
  double k2;
  double kCaSR;


  double dNai;
  double dKi;
  double dCai;
  double dCaSR;
  double dCaSS;
  double dRR;


  double Ek;
  double Ena;
  double Eks;
  double Eca;
  double CaCSQN;
  double bjsr;
  double cjsr;
  double CaSSBuf;
  double bcss;
  double ccss;
  double CaBuf;
  double bc;
  double cc;
  double Ak1;
  double Bk1;
  double rec_iK1;
  double rec_ipK;
  double rec_iNaK;
  double AM;
  double BM;
  double AH_1;
  double BH_1;
  double AH_2;
  double BH_2;
  double AJ_1;
  double BJ_1;
  double AJ_2;
  double BJ_2;
  double M_INF;
  double H_INF;
  double J_INF;
  double TAU_M;
  double TAU_H;
  double TAU_J;
  double axr1;
  double bxr1;
  double axr2;
  double bxr2;
  double Xr1_INF;
  double Xr2_INF;
  double TAU_Xr1;
  double TAU_Xr2;
  double Axs;
  double Bxs;
  double Xs_INF;
  double TAU_Xs;
  double R_INF;
  double TAU_R;
  double S_INF;
  double TAU_S;
  double Ad;
  double Bd;
  double Cd;
  double Af;
  double Bf;
  double Cf;
  double Af2;
  double Bf2;
  double Cf2;
  double TAU_D;
  double D_INF;
  double TAU_F;
  double F_INF;
  double TAU_F2;
  double F2_INF;
  double TAU_FCaSS;
  double FCaSS_INF;


  static double inverseVcF2=1/(2*Vc*F);
  static double inverseVcF=1./(Vc*F);
  static double inversevssF2=1/(2*Vss*F);

  static char s[200];
  //FILE *FFtt;
  FILE *FFIKr;
  FILE *FFIKs;
  FILE *FFIK1;
  FILE *FFIto;
  FILE *FFINa;
  FILE *FFIbNa;
  FILE *FFINaK;
  FILE *FFICaL;
  FILE *FFINaL;
  FILE *FFIbCa;
  FILE *FFINaCa;
  FILE *FFIrel;
  FILE *FFIup;
  FILE *FFIleak;
  FILE *FFIxfer;
  FILE *FFIKATP;
  FILE *FFNai;
  FILE *FFKi;
  FILE *FFCai;
  FILE *FFCaSR;
  FILE *FFCaSS;
  FILE *FFsvolt;

  // define all variables
#define       sm          (*V).M
#define       sh          (*V).H
#define       sj          (*V).J
#define       sxr1        (*V).Xr1
#define       sxr2        (*V).Xr2
#define       sxs         (*V).Xs
#define       ss          (*V).S
#define       sr          (*V).R
#define       sd          (*V).D
#define       sf          (*V).F
#define       sf2         (*V).F2
#define       sfcass      (*V).FCass
#define       sRR         (*V).RR
#define       sOO         (*V).OO
#define       svolt       (*V).Volt
#define       svolt2      (*V).Volt2
#define       Cai         (*V).Cai
#define       CaSR        (*V).CaSR
#define       CaSS        (*V).CaSS
#define       Nai         (*V).Nai
#define       Ki          (*V).Ki
#define       sItot       (*V).Itot

  //Calculate ADP
     FILE *FFADP;
     /*if(svolt>Vmax)//ȡVmax��Ӧ��tΪt0
     {
          Vmax=svolt;
          t_0=*tt;
     }*/

     if(svolt>Vmax)//ȡdv/dt_max��Ӧ��tΪt0
     {
          V_post=svolt;
          Slope_post=(V_post-V_pre)/0.02;
          if(Slope_post>=Slope_pre)
          {
               V_pre=V_post;
               t_0=*tt;
               Slope_pre=Slope_post;
          }

          Vmax=svolt;
          //t_0=*tt;
     }
     if(abs(svolt-(Vmax-0.9*(Vmax-Vrest)))<0.01)
     {
          t_end=*tt;
          ADP=t_end-t_0;
     }

     if(step%50000==0)
     {
          V_pre=-86.2;  //liang
          Slope_pre=0;  //liang
          Vmax=-90;
          sprintf(s,"%s","ADP.dat");
          FFADP=fopen(s,"a");
          fprintf(FFADP,"%4.10f\t",step*0.02);
          fprintf(FFADP,"%4.10f\t",ADP);
          fprintf(FFADP,"\n");
          printf("APD=%f\t",ADP);
     }
     fclose(FFADP);


    //Needed to compute currents
    Ek=RTONF*(log((Ko/Ki)));
    Ena=RTONF*(log((Nao/Nai)));
    Eks=RTONF*(log((Ko+pKNa*Nao)/(Ki+pKNa*Nai)));
    Eca=0.5*RTONF*(log((Cao/Cai)));
    Ak1=0.1/(1.+exp(0.06*(svolt-Ek-200)));
    Bk1=(3.*exp(0.0002*(svolt-Ek+100))+
	 exp(0.1*(svolt-Ek-10)))/(1.+exp(-0.5*(svolt-Ek)));
    rec_iK1=Ak1/(Ak1+Bk1);
    rec_iNaK=(1./(1.+0.1245*exp(-0.1*svolt*F/(R*T))+0.0353*exp(-svolt*F/(R*T))));
    rec_ipK=1./(1.+exp((25-svolt)/5.98));


    //Compute currents
    INa=GNa*sm*sm*sm*sh*sj*(svolt-Ena);
    ICaL=0.5*GCaL*sd*sf*sf2*sfcass*4*(svolt-15)*(F*F/(R*T))*//liang_change
      (0.25*exp(2*(svolt-15)*F/(R*T))*CaSS-Cao)/(exp(2*(svolt-15)*F/(R*T))-1.);
    Ito=Gto*sr*ss*(svolt-Ek);
    IKr=Gkr*sqrt(Ko/5.4)*sxr1*sxr2*(svolt-Ek);
    IKs=Gks*sxs*sxs*(svolt-Eks);
    IK1=GK1*rec_iK1*(svolt-Ek);
    INaCa=0.6*knaca*(1./(KmNai*KmNai*KmNai+Nao*Nao*Nao))*(1./(KmCa+Cao))*//liang_change
      (1./(1+ksat*exp((n-1)*svolt*F/(R*T))))*
      (exp(n*svolt*F/(R*T))*Nai*Nai*Nai*Cao-
       exp((n-1)*svolt*F/(R*T))*Nao*Nao*Nao*Cai*2.5);
    INaK=0.46*knak*(Ko/(Ko+KmK))*(Nai/(Nai+KmNa))*rec_iNaK;//liang_change_new
    IpCa=GpCa*Cai/(KpCa+Cai);
    IpK=GpK*rec_ipK*(svolt-Ek);
    IbNa=GbNa*(svolt-Ena);
    IbCa=1.3*GbCa*(svolt-Eca);//liang_change

/*
    p0=0.91;                                                        //liang_change
    K0hMg=0.65/(sqrt(Ko+5));                                        //liang_change
    KhMg=K0hMg*exp(-2*0.32*svolt*F/(R*T));                          //liang_change
    fM=1./(1+Mgi/KhMg);                                             //liang_change
    KhNa=25.9*exp(-2*0.35**svolt*F/(R*T));                          //liang_change  Mgi
    fN=1./(1+(Nai/KhNa)*(Nai/KhNa))                                 //liang_change
    fT=pow(1.3,(T-36)/10);                                          //liang_change  T
    Km=35.8+17.9*pow(ADPi,0.256);                                   //liang_change
    H=1.3+0.74*exp(-0.09*ADPi)                                      //liang_change
    fATP=1./(1+pow(ATPi/Km,H));                                     //liang_change
    IKATP=GATP/Am*pow((Ko/Ko_ctrl),n)*p0*fM*fN*fT*fATP*(svolt-Ek)   //liang_change  GATP    Am    Ko_ctrl   n     ��ΰ��
*/
    // ����IKATP����    liang_change
    //���ݣ�2011_Experiment-model interaction for analysis of epicardial activation during human ventricular fibrillation with global myocardial ischaemia
    double GKATP=3.9;                                               //liang_change
    double H=2.0;                                                   //liang_change
    double n=0.24;                                                  //liang_change
    double ATPi=4.6;              //liang_change_new    0.15;//
    double Khalf=0.25;         //liang_change_new       0.6676;//
    double IKATP=GKATP*(1/(1+pow(ATPi/Khalf,H)))*pow(Ko/5.4,n)*(svolt-Ek);//liang_change

     //��ORDģ�����INaL����    //liang_change
     //��ʼ��INaL�õ��Ĳ��� //liang_change
     double mL=0;
     double hL=1;
     double mLss=1.0/(1.0+exp((-(svolt+42.85))/5.264));
     double tmL=1.0/(6.765*exp((svolt+11.64)/34.77)+8.552*exp(-(svolt+77.42)/5.955));
     mL=mLss-(mLss-mL)*exp(-HT/tmL);
     double hLss=1.0/(1.0+exp((svolt+87.61)/7.488));
     double thL=200.0;
     hL=hLss-(hLss-hL)*exp(-HT/thL);
     double GNaL=0.0075;
     INaL=GNaL*(svolt-Ena)*mL*hL;

    //Determine total current
    (sItot) = IKr    +
      IKs   +
      IK1   +
      Ito   +
      INa   +
      IbNa  +
      ICaL  +
      IbCa  +
      INaK  +
      INaCa +
      IpCa  +
      IpK   +
      IKATP +
      INaL +                                                            //liang_chang
      Istim;





    //update concentrations
    kCaSR=maxsr-((maxsr-minsr)/(1+(EC/CaSR)*(EC/CaSR)));
    k1=k1_/kCaSR;
    k2=k2_*kCaSR;
    dRR=k4*(1-sRR)-k2*CaSS*sRR;
    sRR+=HT*dRR;
    sOO=k1*CaSS*CaSS*sRR/(k3+k1*CaSS*CaSS);


    Irel=0.65*Vrel*sOO*(CaSR-CaSS);//liang_change_new
    Ileak=Vleak*(CaSR-Cai);
    Iup=0.9*Vmaxup/(1.+((Kup*Kup)/(Cai*Cai)));//liang_change_new
    Ixfer=Vxfer*(CaSS-Cai);


    CaCSQN=Bufsr*CaSR/(CaSR+Kbufsr);
    dCaSR=HT*(Iup-Irel-Ileak);
    bjsr=Bufsr-CaCSQN-dCaSR-CaSR+Kbufsr;
    cjsr=Kbufsr*(CaCSQN+dCaSR+CaSR);
    CaSR=(sqrt(bjsr*bjsr+4*cjsr)-bjsr)/2;


    CaSSBuf=Bufss*CaSS/(CaSS+Kbufss);
    dCaSS=HT*(-Ixfer*(Vc/Vss)+Irel*(Vsr/Vss)+(-ICaL*inversevssF2*CAPACITANCE));
    bcss=Bufss-CaSSBuf-dCaSS-CaSS+Kbufss;
    ccss=Kbufss*(CaSSBuf+dCaSS+CaSS);
    CaSS=(sqrt(bcss*bcss+4*ccss)-bcss)/2;


    CaBuf=Bufc*Cai/(Cai+Kbufc);
    dCai=HT*((-(IbCa+IpCa-2*INaCa)*inverseVcF2*CAPACITANCE)-(Iup-Ileak)*(Vsr/Vc)+Ixfer);
    bc=Bufc-CaBuf-dCai-Cai+Kbufc;
    cc=Kbufc*(CaBuf+dCai+Cai);
    Cai=(sqrt(bc*bc+4*cc)-bc)/2;


    dNai=-(INa+IbNa+3*INaK+3*INaCa)*inverseVcF*CAPACITANCE;
    Nai+=HT*dNai;

    dKi=-(Istim+IK1+Ito+IKr+IKs-2*INaK+IpK)*inverseVcF*CAPACITANCE;
    Ki+=HT*dKi;

    if(step%10==0)   //step>=4999000
    {
    sprintf(s,"%s","svolt.dat");
	FFsvolt=fopen(s,"a");
    fprintf(FFsvolt,"%4.10f\t",*tt);//(*tt)-100000
	fprintf(FFsvolt,"%4.10f",svolt);
	fprintf(FFsvolt,"\n");
	fclose(FFsvolt);
    }
    //write currents to file
    /*if(step>=4999000)//if(step%10==0&&step>=4999000)    if(step%10==0)ÿ��10�����ݻ�һ����  step>=19949000��¼���ǵ�400������ǰ20sʱ��ʼʱ�̣�step>=449000��¼���ǵ�10����ǰ20ms   liang_change
      {//step>=4949000;100�Σ�step>=9949000;200�Σ�step>=14949000;300�Σ�step>=24949000��500�Σ�step>=199000��5��
	//sprintf(s,"%s","Currents.dat");//ԭ����
	//FF=fopen(s,"a");                 //ԭ����
	//sprintf(s,"%s","tt.dat");
	//FFtt=fopen(s,"a");
	sprintf(s,"%s","IKr.dat");
	FFIKr=fopen(s,"a");
	sprintf(s,"%s","IKs.dat");
	FFIKs=fopen(s,"a");
	sprintf(s,"%s","IK1.dat");
	FFIK1=fopen(s,"a");
	sprintf(s,"%s","Ito.dat");
	FFIto=fopen(s,"a");
	sprintf(s,"%s","INa.dat");
	FFINa=fopen(s,"a");
	sprintf(s,"%s","IbNa.dat");
	FFIbNa=fopen(s,"a");
	sprintf(s,"%s","INaK.dat");
	FFINaK=fopen(s,"a");
	sprintf(s,"%s","ICaL.dat");
	FFICaL=fopen(s,"a");
	sprintf(s,"%s","INaL.dat");
	FFINaL=fopen(s,"a");
	sprintf(s,"%s","IbCa.dat");
	FFIbCa=fopen(s,"a");
	sprintf(s,"%s","INaCa.dat");
	FFINaCa=fopen(s,"a");
	sprintf(s,"%s","Irel.dat");
	FFIrel=fopen(s,"a");
	sprintf(s,"%s","Iup.dat");
	FFIup=fopen(s,"a");
	sprintf(s,"%s","Ileak.dat");
	FFIleak=fopen(s,"a");
	sprintf(s,"%s","Ixfer.dat");
	FFIxfer=fopen(s,"a");
	sprintf(s,"%s","IKATP.dat");
	FFIKATP=fopen(s,"a");
	sprintf(s,"%s","Nai.dat");
	FFNai=fopen(s,"a");
	sprintf(s,"%s","Ki.dat");
	FFKi=fopen(s,"a");
	sprintf(s,"%s","Cai.dat");
	FFCai=fopen(s,"a");
	sprintf(s,"%s","CaSR.dat");
	FFCaSR=fopen(s,"a");
	sprintf(s,"%s","CaSS.dat");
	FFCaSS=fopen(s,"a");
	sprintf(s,"%s","svolt.dat");
	FFsvolt=fopen(s,"a");

	//fprintf(FFtt,"%4.10f\t",(*tt));//֮ǰ����һ������ȫ��FF
	//fprintf(FFIKr,"%4.10f\t",(*tt)-399000);//��399*1000��ʼ��¼��Ҳ���ǵ�400��
	//fprintf(FFIKr,"%4.10f\t",(*tt)-299000);//��399*1000��ʼ��¼��Ҳ���ǵ�300��
	//fprintf(FFIKr,"%4.10f\t",(*tt)-199000);//��399*1000��ʼ��¼��Ҳ���ǵ�200��
	//fprintf(FFIKr,"%4.10f\t",(*tt)-99000);//��399*1000��ʼ��¼��Ҳ���ǵ�100��
	//fprintf(FFIKr,"%4.10f\t",(*tt)-9000);//��399*1000��ʼ��¼��Ҳ���ǵ�10��
	fprintf(FFIKr,"%4.10f\t",(*tt)-100000);//��399*1000��ʼ��¼��Ҳ���ǵ�400��
	fprintf(FFIKr,"%4.10f\t",IKr);
	fprintf(FFIKr,"\n");
	fprintf(FFIKs,"%4.10f\t",(*tt)-100000);
	fprintf(FFIKs,"%4.10f\t",IKs);
	fprintf(FFIKs,"\n");
	fprintf(FFIK1,"%4.10f\t",(*tt)-100000);
	fprintf(FFIK1,"%4.10f\t",IK1);
	fprintf(FFIK1,"\n");
	fprintf(FFIto,"%4.10f\t",(*tt)-100000);
	fprintf(FFIto,"%4.10f\t",Ito);
	fprintf(FFIto,"\n");
	fprintf(FFINa,"%4.10f\t",(*tt)-100000);
	fprintf(FFINa,"%4.10f\t",INa);
	fprintf(FFINa,"\n");
	fprintf(FFIbNa,"%4.10f\t",(*tt)-100000);
	fprintf(FFIbNa,"%4.10f\t",IbNa);
	fprintf(FFIbNa,"\n");
	fprintf(FFINaK,"%4.10f\t",(*tt)-100000);
	fprintf(FFINaK,"%4.10f\t",INaK);
	fprintf(FFINaK,"\n");
	fprintf(FFICaL,"%4.10f\t",(*tt)-100000);
	fprintf(FFICaL,"%4.10f\t",ICaL);
	fprintf(FFICaL,"\n");
	fprintf(FFINaL,"%4.10f\t",(*tt)-100000);
	fprintf(FFINaL,"%4.10f\t",INaL);
	fprintf(FFINaL,"\n");
	fprintf(FFIbCa,"%4.10f\t",(*tt)-100000);
	fprintf(FFIbCa,"%4.10f\t",IbCa);
	fprintf(FFIbCa,"\n");
	fprintf(FFINaCa,"%4.10f\t",(*tt)-100000);
	fprintf(FFINaCa,"%4.10f\t",INaCa);
	fprintf(FFINaCa,"\n");
	fprintf(FFIrel,"%4.10f\t",(*tt)-100000);
	fprintf(FFIrel,"%4.10f\t",Irel);
	fprintf(FFIrel,"\n");
	fprintf(FFIup,"%4.10f\t",(*tt)-100000);
	fprintf(FFIup,"%4.10f\t",Iup);
	fprintf(FFIup,"\n");
	fprintf(FFIleak,"%4.10f\t",(*tt)-100000);
	fprintf(FFIleak,"%4.10f\t",Ileak);
	fprintf(FFIleak,"\n");
	fprintf(FFIxfer,"%4.10f\t",(*tt)-100000);
	fprintf(FFIxfer,"%4.10f",Ixfer);
	fprintf(FFIxfer,"\n");
	fprintf(FFIKATP,"%4.10f\t",(*tt)-100000);
	fprintf(FFIKATP,"%4.10f",IKATP);
	fprintf(FFIKATP,"\n");
	fprintf(FFNai,"%4.10f\t",(*tt)-100000);
	fprintf(FFNai,"%4.10f",Nai);
	fprintf(FFNai,"\n");
	fprintf(FFKi,"%4.10f\t",(*tt)-100000);
	fprintf(FFKi,"%4.10f",Ki);
	fprintf(FFKi,"\n");
	fprintf(FFCai,"%4.10f\t",(*tt)-100000);
	fprintf(FFCai,"%4.10f",Cai);
	fprintf(FFCai,"\n");
	fprintf(FFCaSR,"%4.10f\t",(*tt)-100000);
	fprintf(FFCaSR,"%4.10f",CaSR);
	fprintf(FFCaSR,"\n");
	fprintf(FFCaSS,"%4.10f\t",(*tt)-100000);
	fprintf(FFCaSS,"%4.10f",CaSS);
	fprintf(FFCaSS,"\n");
	fprintf(FFsvolt,"%4.10f\t",(*tt)-100000);
	fprintf(FFsvolt,"%4.10f",svolt);
	fprintf(FFsvolt,"\n");
	//fprintf(FF,"\n");
	//fclose(FF);
	//fclose(FFtt);
	fclose(FFIKr);
	fclose(FFIKs);
	fclose(FFIK1);
	fclose(FFIto);
	fclose(FFINa);
	fclose(FFIbNa);
	fclose(FFINaK);
	fclose(FFICaL);
	fclose(FFINaL);
	fclose(FFIbCa);
	fclose(FFINaCa);
	fclose(FFIrel);
	fclose(FFIup);
	fclose(FFIleak);
	fclose(FFIxfer);
	fclose(FFIKATP);
	fclose(FFNai);
	fclose(FFKi);
	fclose(FFCai);
	fclose(FFCaSR);
	fclose(FFCaSS);
	fclose(FFsvolt);
      }*/

    //compute steady state values and time constants
    AM=1./(1.+exp((-60.-svolt)/5.));
    BM=0.1/(1.+exp((svolt+35.)/5.))+0.10/(1.+exp((svolt-50.)/200.));
    TAU_M=AM*BM;
    M_INF=1./((1.+exp((-56.86-svolt)/9.03))*(1.+exp((-56.86-svolt)/9.03)));
    if (svolt>=-40.)
      {
	AH_1=0.;
	BH_1=(0.77/(0.13*(1.+exp(-(svolt+10.66)/11.1))));
	TAU_H= 1.0/(AH_1+BH_1);
      }
    else
      {
	AH_2=(0.057*exp(-(svolt+80.)/6.8));
	BH_2=(2.7*exp(0.079*svolt)+(3.1e5)*exp(0.3485*svolt));
	TAU_H=1.0/(AH_2+BH_2);
      }
    H_INF=1./((1.+exp((svolt+71.55)/7.43))*(1.+exp((svolt+71.55)/7.43)));
    if(svolt>=-40.)
      {
	AJ_1=0.;
	BJ_1=(0.6*exp((0.057)*svolt)/(1.+exp(-0.1*(svolt+32.))));
	TAU_J= 1.0/(AJ_1+BJ_1);
      }
    else
      {
	 AJ_2=(((-2.5428e4)*exp(0.2444*svolt)-(6.948e-6)*
		exp(-0.04391*svolt))*(svolt+37.78)/
	       (1.+exp(0.311*(svolt+79.23))));
	 BJ_2=(0.02424*exp(-0.01052*svolt)/(1.+exp(-0.1378*(svolt+40.14))));
	 TAU_J= 1.0/(AJ_2+BJ_2);
      }
    J_INF=H_INF;

    Xr1_INF=1./(1.+exp((-26.-svolt)/7.));
    axr1=450./(1.+exp((-45.-svolt)/10.));
    bxr1=6./(1.+exp((svolt-(-30.))/11.5));
    TAU_Xr1=axr1*bxr1;
    Xr2_INF=1./(1.+exp((svolt-(-88.))/24.));
    axr2=3./(1.+exp((-60.-svolt)/20.));
    bxr2=1.12/(1.+exp((svolt-60.)/20.));
    TAU_Xr2=axr2*bxr2;

    Xs_INF=1./(1.+exp((-5.-svolt)/14.));
    Axs=(1400./(sqrt(1.+exp((5.-svolt)/6))));
    Bxs=(1./(1.+exp((svolt-35.)/15.)));
    TAU_Xs=Axs*Bxs+80;

#ifdef EPI
    R_INF=1./(1.+exp((20-svolt)/6.));
    S_INF=1./(1.+exp((svolt+20)/5.));
    TAU_R=9.5*exp(-(svolt+40.)*(svolt+40.)/1800.)+0.8;
    TAU_S=85.*exp(-(svolt+45.)*(svolt+45.)/320.)+5./(1.+exp((svolt-20.)/5.))+3.;
#endif
#ifdef ENDO
    R_INF=1./(1.+exp((20-svolt)/6.));
    S_INF=1./(1.+exp((svolt+28)/5.));
    TAU_R=9.5*exp(-(svolt+40.)*(svolt+40.)/1800.)+0.8;
    TAU_S=1000.*exp(-(svolt+67)*(svolt+67)/1000.)+8.;
#endif
#ifdef MCELL
    R_INF=1./(1.+exp((20-svolt)/6.));
    S_INF=1./(1.+exp((svolt+20)/5.));
    TAU_R=9.5*exp(-(svolt+40.)*(svolt+40.)/1800.)+0.8;
    TAU_S=85.*exp(-(svolt+45.)*(svolt+45.)/320.)+5./(1.+exp((svolt-20.)/5.))+3.;
#endif


     D_INF=1./(1.+exp((-8-svolt)/7.5));
     Ad=1.4/(1.+exp((-35-svolt)/13))+0.25;
     Bd=1.4/(1.+exp((svolt+5)/5));
     Cd=1./(1.+exp((50-svolt)/20));
     TAU_D=Ad*Bd+Cd;
     F_INF=1./(1.+exp((svolt+20)/7));
     Af=1102.5*exp(-(svolt+27)*(svolt+27)/225);
     Bf=200./(1+exp((13-svolt)/10.));
     Cf=(180./(1+exp((svolt+30)/10)))+20;
     TAU_F=Af+Bf+Cf;
     F2_INF=0.67/(1.+exp((svolt+35)/7))+0.33;
     Af2=600*exp(-(svolt+25)*(svolt+25)/170);
     Bf2=31/(1.+exp((25-svolt)/10));
     Cf2=16/(1.+exp((svolt+30)/10));
     TAU_F2=Af2+Bf2+Cf2;
     FCaSS_INF=0.6/(1+(CaSS/0.05)*(CaSS/0.05))+0.4;
     TAU_FCaSS=80./(1+(CaSS/0.05)*(CaSS/0.05))+2.;



     //Update gates
     sm = M_INF-(M_INF-sm)*exp(-HT/TAU_M);
     sh = H_INF-(H_INF-sh)*exp(-HT/TAU_H);
     sj = J_INF-(J_INF-sj)*exp(-HT/TAU_J);
     sxr1 = Xr1_INF-(Xr1_INF-sxr1)*exp(-HT/TAU_Xr1);
     sxr2 = Xr2_INF-(Xr2_INF-sxr2)*exp(-HT/TAU_Xr2);
     sxs = Xs_INF-(Xs_INF-sxs)*exp(-HT/TAU_Xs);
     ss= S_INF-(S_INF-ss)*exp(-HT/TAU_S);
     sr= R_INF-(R_INF-sr)*exp(-HT/TAU_R);
     sd = D_INF-(D_INF-sd)*exp(-HT/TAU_D);
     sf =F_INF-(F_INF-sf)*exp(-HT/TAU_F);
     sf2 =F2_INF-(F2_INF-sf2)*exp(-HT/TAU_F2);
     sfcass =FCaSS_INF-(FCaSS_INF-sfcass)*exp(-HT/TAU_FCaSS);



     //update voltage
     svolt= svolt + HT*(-sItot);


}
